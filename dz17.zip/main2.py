# создадим шаблон to do list

import os
import json

def create_task(title, description):
    task = {'title': title, 'description': description, 'status': 'not completed'}
    task_filename = f"{title}.json"
    with open(task_filename, 'w') as f:
        json.dump(task, f)
    return task_filename

def load_task(title):
    task_filename = f"{title}.json"
    if os.path.exists(task_filename):
        with open(task_filename, 'r') as f:
            task = json.load(f)
        return task
    else:
        return None

def update_task(title, new_description=None, new_status=None):
    task = load_task(title)
    if task:
        if new_description:
            task['description'] = new_description
        if new_status:
            task['status'] = new_status
        task_filename = f"{title}.json"
        with open(task_filename, 'w') as f:
            json.dump(task, f)
        return task
    else:
        return None

def delete_task(title):
    task_filename = f"{title}.json"
    if os.path.exists(task_filename):
        os.remove(task_filename)
        return True
    else:
        return False

def find_tasks_by_status(status):
    tasks = []
    for filename in os.listdir('.'):
        if filename.endswith('.json') and os.path.isfile(filename):
            with open(filename, 'r') as f:
                task = json.load(f)
                if task['status'] == status:
                    tasks.append(filename.split('.')[0])
    return tasks

def generate_tasks_report():
    report = []
    for filename in os.listdir('.'):
        if filename.endswith('.json') and os.path.isfile(filename):
            with open(filename, 'r') as f:
                task = json.load(f)
                report.append({
                    'title': task['title'],
                    'description': task['description'],
                    'status': task['status']
                })
    with open('report.txt', 'w') as f:
        for task in report:
            f.write(f"Title: {task['title']}\n")
            f.write(f"Description: {task['description']}\n")
            f.write(f"Status: {task['status']}\n\n")


# и дальше подставим наши дела, которые нужно сделать


from todo_list import create_task, load_task, update_task, delete_task, find_tasks_by_status, generate_tasks_report

task_filename = create_task('Посмотреть фильмы', 'Список шиндлера, Зеленая миля, Форрест Гамп')
task = load_task('Посмотреть фильмы')
updated_task = update_task('Посмотреть фильмы', new_status='Просмотрено')
delete_task('Посмотреть фильмы')
completed_tasks = find_tasks_by_status('Просмотрено')
generate_tasks_report()