with open('calc.txt', 'r+') as f:
    expression = f.read()
    result = eval(expression)
    f.seek(0)
    f.write(f"{expression}={result}")
    f.truncate()